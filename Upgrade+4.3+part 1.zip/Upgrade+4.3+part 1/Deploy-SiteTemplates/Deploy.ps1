# Errors should stop the script
$ErrorActionPreference = "stop"

# Files may be blocked if sent via the internet, this ensures that we unblock them
# Will fail if PowerShell was not opened as Administrator
Get-ChildItem '.' -Recurse | Unblock-File

# Import tenant configuration
. ..\Environment.ps1

# Import deployment parameters
Import-Module ..\Files\Instances -Force
Import-Module .\Steps -Force
Import-Module .\Parameters -Force


$steps = Get-Steps
$instances = Get-Instances
$params = Get-Parameters -Instance $instances.Default -SiteTemplates @("Apps", "Navigation", "ContentTypes")


#Execute deployment
Start-Deployment -Steps $steps -Parameters $params -SkipRequirements


# Uncomment this line to rollback
#Start-Deployment -Steps $steps -Parameters $params -IncludeOnly RollbackSteps