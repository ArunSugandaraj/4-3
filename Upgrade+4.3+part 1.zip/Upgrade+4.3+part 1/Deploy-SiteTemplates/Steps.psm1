# Import utility functions
. ..\Utilities\DeploySteps.ps1

$deploymentSteps = @{
  Name        = "Fresh site templates" # For log purposes only.
  # Handle how the script behaves (which actions are performed)
  TenantSteps = @( 
    @{ DeployStep = $DeploySteps.ApplySiteScript; Enabled = $true }
    @{ DeployStep = $DeploySteps.ApplySiteDesign ; Enabled = $true }
  )
}

Function Get-Steps () {
  return $deploymentSteps
}

Export-ModuleMember -Function Get-Steps, Start-Deployment
