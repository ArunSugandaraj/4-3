#############################
## SHAREPOINT SETTINGS     ##
#############################
$global:tenantUrl = "https://fresh.sharepoint.com"
$global:tenantAdminUrl = "https://fresh-admin.sharepoint.com"
$global:defaultSiteOwner = "ccdev@fresh.contentclo.ud"

$global:termStoreLanguages = @(1033, 1036) # English - United States, French - France

############################# 
## AUTHENTICATION SETTINGS ##
#############################
$global:useWebLogin = $false
#Indicate path fo credentials only if $global:useWebLoging = $false
#Run .\Tools\Save-Credentials.ps1 to save the credentials
$global:storedCredentialsPath = "C:\R\Credentials\$global:defaultSiteOwner.xml" 



#############################
## AZURE SETTINGS          ##
#############################
$global:subscriptionId = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX" # You can get this value from https://portal.azure.com --> Cost Management + Billing
$global:tenantDomain = "fresh.contentclo.ud"

$global:azureAssetPrefix = "fresh" # Please use format [Client][Environment]fresh. No more than 12 characters.

### COMMON RESOURCEGROUP
$global:resourceGroupName = $global:azureAssetPrefix + "-resourcegroup"
$global:resourceGroupLocation = "uksouth"

### PROVISIONING
$global:provisioningStorageAccountName = $global:azureAssetPrefix + "storage"
$global:provisioningFunctionAppName = $global:azureAssetPrefix + "-provisioningapp"
