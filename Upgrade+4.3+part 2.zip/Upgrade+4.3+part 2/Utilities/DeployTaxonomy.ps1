﻿<#
.SYNOPSIS
	Imports an exported Taxonomy XML file to SharePoint On-Prem or 365 environment.

.IMPORTANT
	This is not the full orginal version of this file which may be found elsewhere.
	This file has been modified to better integrate with other scripts by only importing functions to the session.
	Calling this script will not perform any actions.

.NOTES
	Created By Paul Matthews, with original input from Luis Manez and Kevin Beckett.
	Modified for integration with Fresh scripts by Paul Ryan.

.LINK 
	http://cannonfodder.wordpress.com -Paul Matthews Blog Post About this.
	http://geeks.ms/blogs/lmanez -Luis Manez Blog
#>
 
function Get-TermStoreInfo($spContext) {
  #$spTaxSession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($spContext)
  $spTaxSession = Get-PnPTaxonomySession
  $spTaxSession.UpdateCache()
  $spContext.Load($spTaxSession)

  try {
    $spContext.ExecuteQuery()
  }
  catch {
    LogError "Error while loading the Taxonomy Session $($_.Exception.Message)"
    exit 1
  }

  if ($spTaxSession.TermStores.Count -eq 0) {
    LogError "The Taxonomy Service is offline or missing"
    exit 1
  }

  $termStore = $spTaxSession.GetDefaultKeywordsTermStore()

  try {
    $spcontext.Load($termStore)
    $spContext.ExecuteQuery()
  }
  catch {
    LogError "Error while getting term store ID: $($_.Exception.Message)"
    exit 1
  }

  return $termStore
}

function Get-TermsToImport($xmlTermsPath, $tokens) {
  [Reflection.Assembly]::LoadWithPartialName("System.Xml.Linq") | Out-Null

  try {
    $content = Get-Content -path $xmlTermsPath -Raw -Encoding UTF8
    if ($null -ne $tokens) {
      $tokens.Keys | ForEach-Object {
        $content = $content -replace "{{$_}}", $tokens[$_]
      }
    }
    $xDoc = [System.Xml.Linq.XDocument]::Parse($content, [System.Xml.Linq.LoadOptions]::None)
    return $xDoc
  }
  catch {
    LogError "Unable to read ExportedTermsXML. Exception: $($_.Exception.Message)"
    exit 1
  }
}

function Set-TermStoreLanguages($spContext, $termStore, $lcidArray) {
  $addedLcid = $false
  $lcidArray | ForEach-Object {
    $lcidToAdd = $_
    $addLcid = !($termStore.Languages -contains $lcidToAdd)
    if ($addLcid) {
      $termStore.AddLanguage($lcidToAdd)
      $addedLcid = $true
    }
  }
  if ($addedLcid) {
    try {
      $termStore.CommitAll()
      $spcontext.Load($termStore)
      $spContext.ExecuteQuery()
    }
    catch {
      LogError "Error while adding languages to term store: $($_.Exception.Message)"
      exit 1
    }
  }
  LogInfo "Ensured languages are enabled: $lcidArray"
}

function Add-Groups($spContext, $termStore, $termsXML, $isSiteCollectionTermStore) {

  foreach ($groupNode in $termsXML.Descendants("Group")) {
			
    $group = $null

    $isSiteCollectionGroup = $groupNode.Attribute("IsSiteCollectionGroup").Value.ToLower() -eq "true"
    if ($isSiteCollectionGroup) {
      LogInfo "Using site collection group"

      $group = $termStore.GetSiteCollectionGroup($spContext.Site, $true)
		
      $spContext.Load($group)
      $spContext.ExecuteQuery()
    }
    else {
      $name = $groupNode.Attribute("Name").Value
      #$description = $groupNode.Attribute("Description").Value
				
      $id = $null
      $hasId = !!$groupNode.Attribute("Id") -and !!$groupNode.Attribute("Id").Value
      if ($hasId) {
        $id = [System.Guid]::Parse($groupNode.Attribute("Id").Value)
        $group = $termStore.GetGroup($id)
      }
      else {
        # If ID is not provided ensure that name is unique
        $groups = $termStore.Groups
        $spContext.Load($groups)
        $spContext.ExecuteQuery()

        $groups = $groups | Where-Object { $_.Name -eq $name }
        if ($groups.Count -ge 1) {
          $group = $groups[0]
        }
      }
      if (-not $name) {
        LogWaiting "Using Group with id: '$id'"
      }
      else {
        LogWaiting "Creating Group: '$name'"
      }

      if ($null -ne $group) {
        try {
          $spContext.Load($group)
          $spContext.ExecuteQuery()
        }
        catch {
          LogError "Error while finding if $name group already exists. $($_.Exception.Message)"
          exit 1
        }
      }
	
      if ($null -eq $group -or $group.ServerObjectIsNull) {

        if ($null -ne $id) {
          $group = $termStore.CreateGroup($name, $id)
        }
        else {
          $group = $termStore.CreateGroup($name, [Guid]::NewGuid())
        }

        $spContext.Load($group)
        try {
          $spContext.ExecuteQuery()
          LogSuccess "Created"
        }
        catch {
          LogError "Error creating new Group $name $($_.Exception.Message)"
          exit 1
        }
      }
      else {
        LogWarning "Already exists"
      }
    }

    Add-TermSets $termsXML $group $termStore $spContext
  }
	
  try {
    $termStore.CommitAll()
    $spContext.ExecuteQuery()
  }
  catch {
    LogError "Error committing changes to server. Exception: $($_.Exception.Message)"
    exit 1
  }
}

function Add-TermSets($termsXML, $group, $termStore, $spContext) {	
  $termSets = $termsXML.Descendants("TermSet") | Where-Object { ($_.Parent.Parent.Attribute("Name").Value -eq ($group.Name -replace "＆", "&")) -or ($_.Parent.Parent.Attribute("Id").Value -eq $group.Id) -or ($group.IsSiteCollectionGroup -and $_.Parent.Parent.Attribute("IsSiteCollectionGroup").Value.ToLower() -eq "true") }
  foreach ($termSetNode in $termSets) {
    $errorOccurred = $false
    $name = $termSetNode.Attribute("Name").Value
    $description = $termSetNode.Attribute("Description").Value
    $customSortOrder = $termSetNode.Attribute("CustomSortOrder").Value

    LogWaiting "Creating TermSet '$name' "

    $termSet = $null

    $id = $null
    $hasId = !!$termSetNode.Attribute("Id") -and !!$termSetNode.Attribute("Id").Value
    if ($hasId) {
      $id = [System.Guid]::Parse($termSetNode.Attribute("Id").Value)
      $termSet = $termStore.GetTermSet($id)
    }
    else {
      # If ID is not provided ensure that name is unique
      $termSets = $group.TermSets #$termStore.GetTermSetsByName($name, $termStore.DefaultLanguage)
      $spContext.Load($termSets)
      $spContext.ExecuteQuery()
			
      $termSets = $termSets | Where-Object { $_.Name -eq $name }
      if ($termSets.Count -ge 1) {
        $termSet = $termSets[0]
      }
    }
	
    if ($null -ne $termSet) {
      try {
        $spContext.Load($termSet)
        $spContext.ExecuteQuery()
      }
      catch {
        LogError "Error while finding if $name termset already exists. $($_.Exception.Message)"
        exit 1
      }
    }
				
    if ($null -eq $termSet -or $termSet.ServerObjectIsNull) {
      if ($null -ne $id) {
        $termSet = $group.CreateTermSet($name, $id, $termStore.DefaultLanguage)
      }
      else {
        $termSet = $group.CreateTermSet($name, [Guid]::NewGuid(), $termStore.DefaultLanguage)
      }
      $termSet.Description = $description
			
      if ($null -ne $customSortOrder -and $customSortOrder -ne "AsDefined") {
        $termSet.CustomSortOrder = $customSortOrder
      }
			
      $termSet.IsAvailableForTagging = [bool]::Parse($termSetNode.Attribute("IsAvailableForTagging").Value)
      $termSet.IsOpenForTermCreation = [bool]::Parse($termSetNode.Attribute("IsOpenForTermCreation").Value)

      if ($null -ne $termSetNode.Element("CustomProperties")) {
        foreach ($custProp in $termSetNode.Element("CustomProperties").Elements("CustomProperty")) {
          $termSet.SetCustomProperty($custProp.Attribute("Key").Value, $custProp.Attribute("Value").Value)
        }
      }
			
      try {
        # commit all and refresh store for each termset to ensure that terms in the termset are available to be pinned in future termsets
        $termStore.CommitAll()
        $termStore.UpdateCache()
        $spContext.ExecuteQuery()

        $termStore = Get-TermStoreInfo $spContext

      }
      catch {
        LogError "Error occurred while creating Term Set $name, $($_.Exception.Message)"
        $errorOccurred = $true
      }

      LogSuccess "Created"
    }
    else {
      LogWarning "Already exists"
    }
			
    if (!$errorOccurred) {
      if ($null -ne $termSetNode.Element("Terms")) {
        LogWaiting "    Creating child terms "
        $termIdsInOrder = @()
        foreach ($termNode in $termSetNode.Element("Terms").Elements("Term")) {
          $termId = Add-Term $termNode $null $termSet $termStore $spContext
          $termIdsInOrder += $termId
        }
        LogInfo ""
        if ($customSortOrder -eq "AsDefined") {
          $termSet.CustomSortOrder = $termIdsInOrder -join ":"
          #$spContext.Load($termSet)
          #$spContext.ExecuteQuery()
        }
      }	
    }						
  }
}


function Add-Term($termNode, $parentTerm, $termSet, $store, $spContext) {
  if (!$termNode.Attribute("Name")) { return } # Deal with empty <Term></Term> nodes

  $term = $null
  $name = $termNode.Attribute("Name").Value -replace "&", "＆"
	
  # ID is optional, if provided ensure it is unique
  $id = $null
  $hasId = !!$termNode.Attribute("Id") -and !!$termNode.Attribute("Id").Value
  if ($hasId) {
    $id = [System.Guid]::Parse($termNode.Attribute("Id").Value)
    $term = $store.GetTerm($id)
  }

  $isAlreadyAdded = $false
  # If ID is not provided ensure that name is unique
  $terms = $null
  if ($null -ne $parentTerm) {
    $terms = $parentTerm.Terms
  }
  else {
    $terms = $termSet.Terms
  }
  $spContext.Load($terms)
  $spContext.ExecuteQuery()

  $terms = $terms | Where-Object { $_.Name -eq $name -or $_.Id -eq $id }
  if ($terms.Count -ge 1) {
    $term = $terms[0]
    $isAlreadyAdded = $true
  }
	
  if (!$isAlreadyAdded) {
    if ($null -ne $term) {
      try {
        $spContext.Load($term)
        $spContext.ExecuteQuery()
      }
      catch {
        LogError "Error while finding if $name term already exists. $($_.Exception.Message)"
        exit 1
      }
    }

    $isReused = If (!!$termNode.Attribute("IsReused")) { [bool]::Parse($termNode.Attribute("IsReused").Value) } Else { $false }

    if ($isReused -eq $true -and $hasId -eq $true -and $null -ne $term -and $term.ServerObjectIsNull -eq $false) {
      $reuseBranch = $false
      if ($null -ne $parentTerm) {
        $term = $parentTerm.ReuseTerm($term, $reuseBranch)
		    }
      else {
        $term = $termSet.ReuseTerm($term, $reuseBranch)
		    }

      $term.IsAvailableForTagging = [bool]::Parse($termNode.Attribute("IsAvailableForTagging").Value)

		    $customSortOrder = $termNode.Attribute("CustomSortOrder").Value
		    if ($null -ne $customSortOrder -and $customSortOrder -ne "AsDefined") {
        $term.CustomSortOrder = $customSortOrder
		    }

      $spContext.Load($term)
      $spContext.ExecuteQuery()

      write-host "O" -ForegroundColor Green -NoNewline
    }
    else {
      #LogWaiting "Creating Term $name ..." 
      $errorOccurred = $false
      if ($null -eq $term -or $term.ServerObjectIsNull) {
        if ($null -ne $parentTerm) {
          if ($null -ne $id) {
            $term = $parentTerm.CreateTerm($name, $termStore.DefaultLanguage, $id)
          }
          else {
            $term = $parentTerm.CreateTerm($name, $termStore.DefaultLanguage, [Guid]::NewGuid())
          }
        }
        else {
          if ($null -ne $id) {
            $term = $termSet.CreateTerm($name, $termStore.DefaultLanguage, $id)
          }
          else {
            $term = $termSet.CreateTerm($name, $termStore.DefaultLanguage, [Guid]::NewGuid())
          }
        }


        $term.IsAvailableForTagging = [bool]::Parse($termNode.Attribute("IsAvailableForTagging").Value)

        $customSortOrder = $termNode.Attribute("CustomSortOrder").Value
        if ($null -ne $customSortOrder -and $customSortOrder -ne "AsDefined") {
          $term.CustomSortOrder = $customSortOrder
        }

        if ($null -ne $termNode.Element("CustomProperties")) {
          foreach ($custPropElement in $termNode.Element("CustomProperties").Elements("CustomProperty")) {
            $term.SetCustomProperty($custPropElement.Attribute("Key").Value, $custPropElement.Attribute("Value").Value)
          }
        }

        if ($null -ne $termNode.Element("LocalCustomProperties")) {
          foreach ($localCustPropElement in $termNode.Element("LocalCustomProperties").Elements("LocalCustomProperty")) {
            $term.SetLocalCustomProperty($localCustPropElement.Attribute("Key").Value, $localCustPropElement.Attribute("Value").Value)
          }
        }

        if ($null -ne $termNode.Element("Descriptions")) {
          foreach ($descriptionElement in $termNode.Element("Descriptions").Elements("Description")) {
            $descr = $descriptionElement.Attribute("Value").Value
            if ($null -ne $descr -and $descr.Length -gt 0) {
              $labelLcid = [int]::Parse($descriptionElement.Attribute("Language").Value)
              if ($termStore.DefaultLanguage -ne $labelLcid -and $termStore.Languages -contains $labelLcid) {
                $term.SetDescription($descr, $labelLcid)
              }
            }
          }
        }

        if ($null -ne $termNode.Element("Labels")) {
          foreach ($labelElement in $termNode.Element("Labels").Elements("Label")) {
            $labelLcid = [int]::Parse($labelElement.Attribute("Language").Value)
            if (($termStore.DefaultLanguage -ne $labelLcid) -and ($termStore.Languages -contains $labelLcid)) {
              $label = $labelElement.Attribute("Value").Value

              if ($null -ne $label -and $label.Length -gt 0) {
                $isDefault = $labelElement.Attribute("IsDefaultForLanguage").Value -eq "True"
                $term.CreateLabel($label, $labelLcid, $isDefault)
              }
            }
          }
        }

        try {
          $spContext.Load($term)
          $spContext.ExecuteQuery()
          #Start-Sleep -s 5 #To avoid > Term set update failed because of save conflict.
          #LogSuccess "."
          write-host "o" -ForegroundColor Green -NoNewline
        }
        catch {
          LogError "Error occurred while create Term $name $($_.Exception.Message)"
          $errorOccurred = $true
        }
      }
      else {
        #Start-Sleep -s 1 #To avoid > Term set update failed because of save conflict.
        #LogWarning "Already exists"
        write-host "_" -ForegroundColor Yellow -NoNewline
      }
    }
  }
  else {
    #Start-Sleep -s 1 #To avoid > Term set update failed because of save conflict.
    #LogWarning "Already exists"
    write-host "_" -ForegroundColor Yellow -NoNewline
  }

  if (!$errorOccurred) {
    if ($null -ne $termNode.Element("Terms")) {
      # Create child terms
      $termIdsInOrder = @()
      foreach ($childTermNode in $termNode.Element("Terms").Elements("Term")) {
        $termId = Add-Term $childTermNode $term $termSet $store $spContext
        $termIdsInOrder += $termId
      }

      if ($customSortOrder -eq "AsDefined") {
        #if ($null -ne $parentTerm) {
        $term.CustomSortOrder = $termIdsInOrder -join ":"
        $spContext.Load($term)
        $spContext.ExecuteQuery()
        #}
        #else {
        #  $termSet.CustomSortOrder = $termIdsInOrder -join ":"
        #  $spContext.Load($termSet)
        #  $spContext.ExecuteQuery()
        #}
      }
    }
  }

  return $term.Id
}

function Import-Taxonomy ($spContext, $FilePathOfExportXMLTerms, $Tokens, $lcidArray) {
  $termStore = Get-TermStoreInfo $spContext
  LogInfo "Connected to TermStore: $($termStore.Name) ID: $($termStore.Id)"

  $termsXML = Get-TermsToImport $FilePathOfExportXMLTerms $Tokens
  Set-TermStoreLanguages $spContext $termStore $lcidArray

  Add-Groups $spContext $termStore $termsXML
}

