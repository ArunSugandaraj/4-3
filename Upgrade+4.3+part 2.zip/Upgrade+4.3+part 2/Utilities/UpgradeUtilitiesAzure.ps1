﻿. ..\Utilities\DeploySteps.ps1
. ..\Utilities\DeployStepsAzure.ps1

if ($null -eq $global:resourceGroupName) {
  $global:resourceGroupName = $resourceGroupName
}

Function Add-FilesToProvisioningAzure($Source, $Destination, [switch]$CreateFolder) {
  $rg = $global:resourceGroupName
  $sa = $global:provisioningStorageAccountName
  $fa = $global:provisioningFunctionAppName

  Write-Host "Connecting to resource group $rg and storage account $sa"
  Login-Azure

  $key = az storage account keys list --resource-group $rg --account-name $sa --query "[0].value"
  $fileShare = az storage share list --account-key $key --account-name $sa --prefix $fa --query "[0].name"
  Write-Host "Uploading files to $fileShare"

  if ($CreateFolder) {
    $folderName = $Destination | split-path -leaf
    $parentName = $Destination | split-path -parent
    $sibilings = az storage directory list --account-key $key --account-name $sa --name $parentName --share-name $fileShare
    if (-not (($sibilings | ConvertFrom-Json) | Where-Object { $_.name -eq $folderName })) {
      az storage directory create --account-key $key --account-name $sa --name $Destination --share-name $fileShare
    }
  }
  
  az storage file upload-batch --account-key $key --account-name $sa --destination "$fileShare/$Destination" --source $Source
}

Function Remove-FilesFromProvisioningAzure($FolderPath, $FileNames) {
  $rg = $global:resourceGroupName
  $sa = $global:provisioningStorageAccountName
  $fa = $global:provisioningFunctionAppName

  Write-Host "Connecting to resource group and $rg storage account $sa"
  Login-Azure

  $key = az storage account keys list --resource-group $rg --account-name $sa --query "[0].value"
  $fileShare = az storage share list --account-key $key --account-name $sa --prefix $fa --query "[0].name"
  Write-Host "Found files at $fileShare"
 
  $FileNames | ForEach-Object {
    $fileName = $_
    $fileExists = az storage file exists --share-name $fileShare --account-key $key --account-name $sa --path "$FolderPath/$fileName" --query "exists"
    if ($fileExists -eq $true) {
      $q = az storage file delete --share-name $fileShare --account-key $key --account-name $sa --path "$FolderPath/$fileName"
      "$fileName deleted"
    }
    else {
      Write-Host "$fileName not found"
    }
  }
}

Function Upgrade-ProvisioningAzureFunctionApp($zipPackagePath) {
  $rg = $global:resourceGroupName
  $fa = $global:provisioningFunctionAppName

  Write-Host "Connecting to resource group $rg and function app $fa"
  Login-Azure

  Write-Host "Deploying new version of the function app $fa"
  $publishZip = az functionapp deployment source config-zip -g $rg -n $fa --src $zipPackagePath

  Write-Host "Upgrading Framework settings for the function app $fa"

  $updateFunctionVersion = az functionapp config appsettings set --settings FUNCTIONS_EXTENSION_VERSION=~3 -g $rg -n $fa
  
  LogInfo -message "Upgrade completed, the Provisioning Power Automate flow needs to be updated with the new URL of the 'GetRequestApprovers' function HTTP request."
}