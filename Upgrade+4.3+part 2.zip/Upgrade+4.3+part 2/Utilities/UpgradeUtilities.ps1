﻿Import-Module ..\Utilities\DeployConstants
. ..\Utilities\DeploySteps.ps1


Function Update-Solutions ([switch]$Provisioning, [switch]$WebAnalytics, [switch]$CheckList, [switch]$Search) {
  $appPackages = @(
    $CONSTANTS.AppPackages.FreshCoreLibrary
    $CONSTANTS.AppPackages.GlobalStructure
    $CONSTANTS.AppPackages.ContentWebparts
    $CONSTANTS.AppPackages.IntranetWebparts
    $CONSTANTS.AppPackages.UsercentricWebparts
    $CONSTANTS.AppPackages.AnalyticWebparts
    $CONSTANTS.AppPackages.DigitalWorkplaceWebparts
    $CONSTANTS.AppPackages.ToolAdminWebparts
    $CONSTANTS.AppPackages.WebsiteWebparts
    $CONSTANTS.AppPackages.GovernanceWebparts
    $CONSTANTS.AppPackages.MediaWebparts
    $CONSTANTS.AppPackages.DashboardsACEs
  )

  if ($Provisioning) {
    $appPackages += $CONSTANTS.AppPackages.ProvisioningWebparts
  }

  if ($WebAnalytics) {
    $appPackages += $CONSTANTS.AppPackages.WebAnalytics
  }

  if ($CheckList) {
    $appPackages += $CONSTANTS.AppPackages.ChecklistWebparts
  }

  #Authenticate-PnpPowerShell $global:tenantAdminUrl
  #$tenantAppCatalogUrl = Get-PnPTenantAppCatalogUrl
  #Authenticate-PnpPowerShell $tenantAppCatalogUrl
  # 1.1. Publish solutions
  $params = @{ 
    AppPackages          = $appPackages
    OverwriteAppPackages = $true
  }
  Publish-AppPackages $params
}
