Function Merge-Instances {
  param(
    $Instances, 
    $Tenant
  )

  # add tenant keys to the default instance
  $Tenant.Keys | ForEach-Object {
    $Instances.Default[$_] = $Tenant[$_]
  }

  # every instance, except the Default instance, overwrite properties to the Default instance
  $Instances.Keys | Where-Object { $_ -ne "Default" } | ForEach-Object {
    $instanceKey = $_
    # Merge properties
    $Instances.Default.Keys | ForEach-Object {
      if (-not $Instances[$instanceKey].ContainsKey($_)) {
        $Instances[$instanceKey][$_] = $Instances.Default[$_]
      }
    }
    # 2nd level properties
    if ($Instances.Default.NavigationParameters) {
      $Instances.Default.NavigationParameters.Keys | ForEach-Object { 
        if (-not $Instances[$instanceKey].NavigationParameters.ContainsKey($_)) {
          $Instances[$instanceKey].NavigationParameters[$_] = $Instances.Default.NavigationParameters[$_] 
        }
      }
    }
    if ($Instances.Default.FreshTaxParameters) {
      $Instances.Default.FreshTaxParameters.Keys | ForEach-Object { 
        if (-not $Instances[$instanceKey].FreshTaxParameters.ContainsKey($_)) {
          $Instances[$instanceKey].FreshTaxParameters[$_] = $Instances.Default.FreshTaxParameters[$_]
        }
      }
    }
  }
  
  #update the structure of taxonomies
  $Instances.Keys | ForEach-Object {
    $instanceKey = $_
    if (-not $Instances[$instanceKey].FreshTaxParameters.ContainsKey("FreshFields")) {
      $Instances[$instanceKey].FreshTaxParameters["FreshFields"] = @(
        @{
          InternalName    = "CandC_Tax_1"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax1FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax1TermSetGuid
          FieldGuid       = "f0f184d7-0b9b-444f-94bc-10343587c733"
          HiddenFieldGuid = "84641813-a20f-4c7b-8b3d-87720525551d"
        }
        @{
          InternalName    = "CandC_Tax_2"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax2FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax2TermSetGuid
          FieldGuid       = "6454b680-6f34-4f01-97ca-34334082f070"
          HiddenFieldGuid = "97d13533-fea9-4a34-a472-cdde2a29b5b4"
        }
        @{
          InternalName    = "CandC_Tax_3"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax3FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax3TermSetGuid
          FieldGuid       = "759fb41c-e9f4-4f8d-a428-53bd45fa9de8"
          HiddenFieldGuid = "2bdfadfd-1cd0-4226-87cd-a2e75d382585"
        }
        @{
          InternalName    = "CandC_Tax_4"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax4FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax4TermSetGuid
          FieldGuid       = "7884c4a6-666a-4c96-8d95-b481dcac504b"
          HiddenFieldGuid = "90e85f51-4973-46c9-aea3-64075d8cd763"
        }
        @{
          InternalName    = "CandC_Tax_5"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax5FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax5TermSetGuid
          FieldGuid       = "8EC7B074-A3BE-4541-ACC0-5FFDCCE0B2ED"
          HiddenFieldGuid = "E14D4B64-1F8E-4D21-8BE9-53E28075F3BE"
        }
        @{
          InternalName    = "CandC_Tax_6"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax6FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax6TermSetGuid
          FieldGuid       = "265A5956-1C57-4A67-958F-C252AEFD9F60"
          HiddenFieldGuid = "4B73AA45-441C-47F6-B9D3-3AFADC785A37"
        }
        @{
          InternalName    = "CandC_Tax_7"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax7FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax7TermSetGuid
          FieldGuid       = "95B187BC-B8E0-4CC3-9D90-48D038784E6D"
          HiddenFieldGuid = "B9BBD514-7787-4A6D-A800-ADE0F4C6413F"
        }
        @{
          InternalName    = "CandC_Tax_8"
          DisplayName     = $Instances[$instanceKey].FreshTaxParameters.FreshTax8FieldName 
          TermSetGuid     = $Instances[$instanceKey].FreshTaxParameters.FreshTax8TermSetGuid
          FieldGuid       = "36CCCF54-ED80-4BEF-98CB-CA575C7AD017"
          HiddenFieldGuid = "C3540778-D1BF-4436-9067-23DC30229F96"
        }
      )
    }
  }

  return $Instances
}

Export-ModuleMember -Function Merge-Instances