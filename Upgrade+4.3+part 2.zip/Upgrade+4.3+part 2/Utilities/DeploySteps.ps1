# Import utility functions
. ..\Utilities\DeployUtilities.ps1

Import-Module ..\Utilities\DeployConstants -Force

Function Start-Deployment($Steps, $Parameters, $IncludeOnly, [switch]$SkipRequirements) {
  # Initiate transciption
  try {
    Start-Transcript -path $CONSTANTS.PathToLogFile -ErrorAction SilentlyContinue
  }
  catch [System.Exception] {
    LogWarning "Unable to start transcription of this session" -f Red
  }

  try {
    # Load assemblies
    # NOTE : Use a recent versions the SharePoint Online Management Shell
    #Import-Module -Name SharePointPnPPowerShellOnline -WarningAction SilentlyContinue
    Load-RequiredAsseblies $librariesFolderPath
    LogWarning ""
    LogWarning ""
    LogSection "You are about to deploy $($Steps.Name) in $($global:tenantUrl)"
    LogWarning ""
    if ($SkipRequirements -eq $null -or -not $SkipRequirements) {
      if ($Steps.Prerrequisites) {
        LogWarning "BEFORE EXECUTING THIS SCRIPT:"
        For ($i = 0; $i -lt $Steps.Prerrequisites.Length; $i++) {
          $pre = $Steps.Prerrequisites[$i]
          LogWarning "$($i+1) - $pre"
        }
      }
      read-host "Press enter to continue"
    }
    $startDate = (Get-Date)
    LogInfo ("Script started: " + $startDate.ToString())
    Deploy-Steps -Steps $Steps -Parameters $Parameters -IncludeOnly $IncludeOnly
  }
  catch [System.Exception] {
    LogError $_ -f Red
    LogError
    LogError $_.ScriptStackTrace
    LogError
    LogError $_.Exception
    LogError
    LogError $_.ErrorDetails
  }
  finally {
    # Print summary
    LogSection "Script end"
    $endDate = (Get-Date)
    LogInfo ("Script started: " + $startDate.ToString())
    LogInfo ("Script ended: " + $endDate.ToString())
    LogDuration $startDate

    Stop-Transcript -ErrorAction SilentlyContinue
    try {
      Disconnect-PnPOnline
    }
    catch { }
  }
}

Function Deploy-Steps ($Steps, $Parameters, $IncludeOnly) {
  [array]$stepsToExecute = @()
  if ($null -eq $IncludeOnly) {
    $stepsToExecute = ([array]$Steps.TenantSteps + [array]$Steps.InstanceSteps + [array]$Steps.SiteSteps)
  }
  else {
    $IncludeOnly | ForEach-Object { $stepsToExecute += [array]$Steps[$_] } 
  }
  $stepsToExecute = $stepsToExecute | Where-Object { $null -ne $_.DeployStep }
  For ($i = 0; $i -lt $stepsToExecute.Length; $i++) {
    $step = $stepsToExecute[$i]
    if ($step.Enabled) {
      LogSection "$($Steps.Name): Step $($i+1) of $($stepsToExecute.Length) - $($step.DeployStep.Name)"
      & $step.DeployStep.Function -parameters $Parameters
    }
    else {
      LogSection "$($Steps.Name): Step $($i+1) of $($stepsToExecute.Length) - $($step.DeployStep.Name) - SKIPPED"
    }
  }
}

## FUNCTIONS


# Delete site collections
Function Delete-SiteCollections ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnpPowerShell $global:tenantAdminUrl
  $isDeleteAny = $false
  $parameters.SiteCollectionInfos | ForEach-Object {
    if ($_.Template) {
      $isDelete = Delete-SiteCollection $_.SiteTitle $_.SiteUrl
      if ($isDelete -eq $true) {
        $isDeleteAny = $true
      }
    }
  }
  # Wait for all site collection to really be deleted
  if ($isDeleteAny -eq $true) {
    $parameters.SiteCollectionInfos | ForEach-Object {
      Wait-DeleteSiteCollection $_.SiteTitle $_.SiteUrl
    }
    # Even then, wait a little longer as sometimes it seems to lie...
    Wait-BetweenEvents
  }
  else {
    LogInfo("Skipped")
  }
  LogDuration $startDate
}

# Remove site collections from recycle bin
Function Remove-SiteCollectionsFromRecycleBin ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnpPowerShell $global:tenantAdminUrl
  $isRemoveAny = $false
  $parameters.SiteCollectionInfos | ForEach-Object {
    if ($_.Template) {
      $isRemove = RemoveFromBin-SiteCollection $_.SiteTitle $_.SiteUrl
      if ($isRemove -eq $true) {
        $isRemoveAny = $true
      }
    }
  }
  # Wait for all site collection to really be cleared from the recycle bin
  if ($isRemoveAny -eq $true) {
    $parameters.SiteCollectionInfos | ForEach-Object {
      Wait-RemoveFromBinSiteCollection $_.SiteTitle $_.SiteUrl
    }
    # Even then, wait a little longer as sometimes it seems to lie...
  }
  else {
    LogInfo("Skipped")
  }
  LogDuration $startDate
}

# Create site collections
Function Create-SiteCollections ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnpPowerShell $global:tenantAdminUrl
  $isCreatedAny = $false
  $parameters.SiteCollectionInfos | ForEach-Object {
    if ($_.Template) {
      $isCreated = Create-ModernSiteCollection $_
      if ($isCreated) {
        $isCreatedAny = $true
      }
    }
  }
  # Wait for all site collection to be created
  if ($isCreatedAny) {
    $parameters.SiteCollectionInfos | ForEach-Object {
      Wait-CreateSiteCollection $_.SiteTitle $_.SiteUrl
    }
    # Even then, wait a little longer as sometimes it seems to lie...
    Wait-BetweenEvents
    Wait-BetweenEvents
    Wait-BetweenEvents
  }
  $parameters.SiteCollectionInfos | ForEach-Object {
    if ($_.Template) {
      Set-RegionalSettings $_
    }
  }
  LogDuration $startDate
}

Function Publish-AppPackages ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnpPowerShell $global:tenantUrl
  $apps = Get-PnPApp
  $parameters.AppPackages | ForEach-Object {
    $path = $_.FilePath
    #Check that it doesn't exists
    $appInfo = Get-PnPAppInfo -ProductId $_.ProductId
    $existingApp = $apps | Where-Object { $_.Title -eq $appInfo.Name }
    if ($parameters.OverwriteAppPackages -or -not $existingApp ) {
      LogWaiting "Publishing $($path.replace("$($CONSTANTS.SolutionsFolderPath)\"," ") )"
      if ($_.TenantScope) {
        Add-PnPApp -Path  $path -Publish -Overwrite -SkipFeatureDeployment
      }
      else {
        Add-PnPApp -Path $path -Publish -Overwrite
      }
      LogSuccess "done"
    }
  }
  LogDuration $startDate
}

Function Install-AppPackages ($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($siteInfo.AppPackages) {
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      $apps = Get-PnPApp
      $siteInfo.AppPackages | ForEach-Object {
        $appInfo = Get-PnPAppInfo -ProductId $_.ProductId
        $app = $apps | Where-Object { $_.Title -eq $appInfo.Name }
        if ($app) {
          if ($app.InstalledVersion) {
            LogWaiting "Updating app $appName"
            Update-PnPApp -Identity $app.Id
            LogSuccess "done"
          }
          else {  
            LogWaiting "Installing app $appName"
            Install-PnPApp -Identity $app.Id
            LogSuccess "done"
          }
        }
        else {
          LogError "App $appName not found"
        }
      }
    }
    else {
      LogInfo("Skipped")
    }
  }
  LogDuration $startDate
}

Function Register-HubSites ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnPPowerShell $global:tenantAdminUrl
  $parameters.SiteCollectionInfos | ForEach-Object {
    if ($_.IsHubSite -eq $true) {
      try {
        LogWaiting "Registering hub site $($_.SiteUrl)"
        Register-PnPHubSite -Site $_.SiteUrl #-Principals $null
        LogSuccess "done"
      }
      catch {}
    }
    else {
      LogInfo("Skipped")
    }
  }
  LogDuration $startDate
}

Function Join-HubSites ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnPPowerShell $global:tenantAdminUrl
  $parameters.SiteCollectionInfos | ForEach-Object {
    if ($_.HubSite) {
      LogWaiting "Joining site $($_.SiteUrl) to $($_.HubSite)"
      Add-PnPHubSiteAssociation -Site $_.SiteUrl -HubSite $_.HubSite
      LogSuccess "done"
    }
    else {
      LogInfo("Hub site was not declared")
    }
  }
  LogDuration $startDate
}


# Import search schema
Function Import-SearchSchema ($parameters) {
  $startDate = (Get-Date)
  $parameters.Search | ForEach-Object {
    $searchConfig = $_
    if ($searchConfig.TenantScope -eq $false) {
      $parameters.SiteCollectionInfos | ForEach-Object {
        Authenticate-PnpPowerShell $_.SiteUrl
        LogWaiting "Importing $($searchConfig.FilePath) to $($_.SiteUrl)"
        Set-PnPSearchConfiguration -Path $searchConfig.FilePath -Scope "Site"
        LogSuccess "done"
      }
    }
    else {
      Authenticate-PnPPowerShell $global:tenantAdminUrl
      LogWaiting "Importing $($searchConfig.FilePath)"
      Set-PnPSearchConfiguration -Path $searchConfig.FilePath -Scope "Subscription"
      LogSuccess "done"
    }
  }
  LogDuration $startDate
}

# Import taxonomy
Function Import-TaxonomyFiles ($parameters) {
  if ($null -ne $parameters.Taxonomy -and $parameters.Taxonomy.Count -gt 0) {
    $startDate = (Get-Date)
    . ..\Utilities\DeployTaxonomy.ps1
    $parameters.Taxonomy | ForEach-Object {
      $taxonomyConfig = $_
      LogWaiting "Importing $($taxonomyConfig.FilePath)"

      $tokens = $taxonomyConfig.Tokens
      if ($taxonomyConfig.DynamicTokens) {
        $taxonomyConfig.DynamicTokens | ForEach-Object {
          if ($_.Function) {
            $result = & $_.Function $parameters
            $tokens.Add($_.Key, $result);
          }
        }
      }

      if ($taxonomyConfig.UsesSiteCollectionTermStore -eq $true) {
        $parameters.SiteCollectionInfos | ForEach-Object {
          $siteCtx = Authenticate-CSOM $_.SiteUrl 
          Import-Taxonomy $siteCtx $taxonomyConfig.FilePath $tokens $global:termStoreLanguages
          $siteCtx.Dispose()
        }
      }
      else {
        $adminCtx = Authenticate-CSOM $global:tenantAdminUrl
        Import-Taxonomy $adminCtx $taxonomyConfig.FilePath $taxonomyConfig.Tokens $global:termStoreLanguages
        $adminCtx.Dispose()
      }
      LogSuccess "done"
    }
    LogDuration $startDate
  }
  else {
    LogInfo("Skipped")
  }
}


Function Import-InstanceTaxonomyFiles ($parameters) {
  if ($null -ne $parameters.InstanceTaxonomy -and $parameters.InstanceTaxonomy.Count -gt 0) {
    $startDate = (Get-Date)
    . ..\Utilities\DeployTaxonomy.ps1
    $parameters.InstanceTaxonomy | ForEach-Object {
      $taxonomyConfig = $_
      LogWaiting "Importing $($taxonomyConfig.FilePath)..."
      if ($taxonomyConfig.UsesSiteCollectionTermStore -eq $true) {
        $parameters.SiteCollectionInfos | ForEach-Object {
          $siteCtx = Authenticate-CSOM $_.SiteUrl 
          Import-Taxonomy $siteCtx $taxonomyConfig.FilePath $taxonomyConfig.Tokens $global:termStoreLanguages
          $siteCtx.Dispose()
        }
      }
      else {
        $adminCtx = Authenticate-CSOM $global:tenantAdminUrl
        Import-Taxonomy $adminCtx $taxonomyConfig.FilePath $taxonomyConfig.Tokens $global:termStoreLanguages
        $adminCtx.Dispose()
      }
      LogSuccess "done"
    }
    LogDuration $startDate
  }
  else {
    LogInfo("Skipped")
  }
}


Function Create-TaxonomyTerms ($parameters) {
  if ($null -ne $parameters.TaxonomyTerms -and $parameters.TaxonomyTerms.Count -gt 0) {
    $startDate = (Get-Date)
    Authenticate-PnPPowerShell $global:tenantAdminUrl
    $parameters.TaxonomyTerms | ForEach-Object {
      Create-Term $_
    }
    LogDuration $startDate
  }
  else {
    LogInfo("Skipped")
  }
}

Function Apply-ProvisioningTemplate ($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($_.Provisioning) {
      #Authenticate-PnpPowerShell $global:tenantAdminUrl
      #Set-PnpTenantSite -Identity $siteInfo.SiteUrl -DenyAddAndCustomizePages:$false

      #Authenticate-PnpPowerShell $siteInfo.SiteUrl
      #LogWaiting "Cleaning $($site.SiteUrl )"
      #Remove-PnPList -Identity Events -Force
      #Remove-PnPList -Identity Documents -Force
      #LogSuccess "done"

      $siteInfo.Provisioning | ForEach-Object {
        LogWaiting "Applying $($_.FilePath) template to $($siteInfo.SiteUrl)"
        $template = $_
        #generate new file with replaced tokens
        $content = Get-Content -path $template.FilePath -Raw -Encoding UTF8
        if ($null -ne $template.Tokens) {
          $template.Tokens.Keys | ForEach-Object {
            $content = $content -replace "{{$_}}", $template.Tokens[$_]
          }
          $executingScriptDirectory = Split-Path -Parent -Path $PSScriptRoot
          $temporalTemplateName = Split-Path -Leaf -Path $template.FilePath
          $filePath = "$executingScriptDirectory\temp\$temporalTemplateName"
          $content | Out-File -FilePath $filePath 
        }
        else {
          $filePath = $template.FilePath
        }

        if ($template.Parameters) {
          $template.Parameters.Keys | ForEach-Object {
            $siteInfo[$_] = $template.Parameters[$_]
          }
        }        
        if ($template.DynamicParameters) {
          [array]$template.DynamicParameters | ForEach-Object {
            if ($null -ne $_.Function) {
              $siteInfo[$_.Key] = & $_.Function $siteInfo
            }
          }
        }
        try {
          Invoke-PnPSiteTemplate -Path $filePath -ResourceFolder $template.ResourceFolderPath -Parameters $siteInfo
        }
        catch [System.Reflection.ReflectionTypeLoadException] {
          LogError "ReflectionTypeLoad error"
          LogError $_.Exception.LoaderExceptions
        }
        catch [System.Exception] {
          LogError $_ -f Red
          LogError
          LogError $_.ScriptStackTrace
          LogError
          LogError $_.Exception
          LogError
          LogError $_.ErrorDetails
        } 
        LogSuccess "done"
      }

      #Authenticate-PnpPowerShell $global:tenantAdminUrl
      #Set-PnpTenantSite -Identity $siteInfo.SiteUrl -DenyAddAndCustomizePages:$true

    }
    else {
      LogInfo("Skipped")
    }
  }
  LogDuration $startDate
}

Function Apply-ProvisioningTemplateArray ($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($_.ProvisioningArray) {
      #Authenticate-PnpPowerShell $siteInfo.SiteUrl
      $siteInfo.ProvisioningArray | ForEach-Object {
        $provisioningConfig = $_
        LogWaiting "Applying $($provisioningConfig.FilePath) template to $($siteInfo.SiteUrl)"
        $provisioningConfig.Array | ForEach-Object {
          $params = $_
          Authenticate-PnpPowerShell $siteInfo.SiteUrl # <----- Version conflict error when I dont disconnect and reconnect
          if ($provisioningConfig.Parameters) {
            $provisioningConfig.Parameters.Keys | ForEach-Object {
              $params[$_] = $provisioningConfig.Parameters[$_]
            }
          }
          if ($provisioningConfig.DynamicParameters) {
            [array]$provisioningConfig.DynamicParameters | ForEach-Object {
              if ($null -ne $_.Function) {
                $params[$_.Key] = & $_.Function $params
              }
            }
          }
          try {
            Invoke-PnPSiteTemplate -Path $provisioningConfig.FilePath -ResourceFolder $provisioningConfig.ResourceFolderPath -Parameters $params
          }
          catch [System.Reflection.ReflectionTypeLoadException] {
            $_.Exception.LoaderExceptions
          } 
          Disconnect-PnPOnline
        }
        LogSuccess "done"
      }
    }
    else {
      LogInfo("Skipped")
    }
  }
  LogDuration $startDate
}

Function Apply-SiteScript ($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteScripts | ForEach-Object {
    $siteScript = $_
    Authenticate-PnpPowerShell $global:tenantAdminUrl
    LogWaiting "Adding $($siteScript.Name) siteScript to the tenant"

    $content = Get-Content -path $siteScript.JsonPath -Raw -Encoding UTF8
    if ($null -ne $siteScript.Tokens) {
      $siteScript.Tokens.Keys | ForEach-Object {
        $content = $content -replace "{{$_}}", $siteScript.Tokens[$_]
      }
    }
    if ($null -ne $siteScript.InjectActions) {
      $siteScript.InjectActions.Injectors | ForEach-Object {
        $content = Inject-Actions $content  $_  $siteScript.InjectActions.Instance $siteScript.InjectActions.TemplatesPath
      }
    }
    $executingScriptDirectory = Split-Path -Parent -Path $PSScriptRoot
    $fileName = Split-Path -Leaf -Path $siteScript.JsonPath
    $tempFilePath = "$executingScriptDirectory\temp\$fileName"
    $content | Out-File -FilePath $tempFilePath

    try {
      Add-PnPSiteScript -Title $siteScript.Name -Description $siteScript.Description -Content $content
    }
    catch [System.Reflection.ReflectionTypeLoadException] {
      LogError "ReflectionTypeLoad error"
      LogError $_.Exception.LoaderExceptions
    }
    catch [System.Exception] {
      LogError $_ -f Red
      LogError
      LogError $_.ScriptStackTrace
      LogError
      LogError $_.Exception
      LogError
      LogError $_.ErrorDetails
    } 

    LogSuccess "done"
  }
  LogDuration $startDate
}

Function Apply-SiteDesign ($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteDesigns | ForEach-Object {
    $siteDesign = $_
    Authenticate-PnpPowerShell $global:tenantAdminUrl
    LogWaiting "Adding $($siteDesign.Name) site design to the tenant"

    $siteScripts = Get-PnPSiteScript
    $siteScriptsId = @()
  
    $siteDesign.SiteScriptsNames | ForEach-Object {
      $scriptName = $_

      $siteScripts | ForEach-Object {
        if ($_.Title -eq $scriptName) {
          $siteScriptsId += $_.Id
        }
      }
    }

    try {
      Add-PnPSiteDesign -Title $siteDesign.Name -SiteScriptIds $siteScriptsId -Description $siteDesign.Description -WebTemplate CommunicationSite
      LogSuccess "$($siteDesign.Name) site design added to the tenant"
    }
    catch [System.Reflection.ReflectionTypeLoadException] {
      LogError "ReflectionTypeLoad error"
      LogError $_.Exception.LoaderExceptions
    }
    catch [System.Exception] {
      LogError $_ -f Red
      LogError
      LogError $_.ScriptStackTrace
      LogError
      LogError $_.Exception
      LogError
      LogError $_.ErrorDetails
    } 

    LogSuccess "done"
  }
  LogDuration $startDate
}

Function Add-SampleContent ($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($_.SampleContent) {
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      $siteInfo.SampleContent | ForEach-Object {
        $template = $_
        if ($template.Parameters) {
          $template.Parameters.Keys | ForEach-Object {
            $siteInfo[$_] = $template.Parameters[$_]
          }
        }        
        if ($template.DynamicParameters) {
          [array]$template.DynamicParameters | ForEach-Object {
            if ($null -ne $_.Function) {
              $siteInfo[$_.Key] = & $_.Function $siteInfo
            }
          }
        }
        LogWaiting "Applying $($_.FilePath) template to $($siteInfo.SiteUrl)"
        Invoke-PnPSiteTemplate -Path $template.FilePath -ResourceFolder $template.ResourceFolderPath -Parameters $siteInfo
        LogSuccess "done"
      }
    }
    else {
      LogInfo("Skipped")
    }
  }
  LogDuration $startDate
}

Function Add-Theme ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnPPowerShell $global:tenantAdminUrl
  if ($parameters.Theme -and $parameters.Theme.FilePath) {
    $theme = Import-PowerShellDataFile $parameters.Theme.FilePath
    if (-not (Get-PnPTenantTheme | Where-Object { $_.Name -like $theme.themeName })) {
      LogWaiting "Adding $($theme.themeName) theme to $($global:tenantAdminUrl)"
      Add-PnPTenantTheme -Identity $theme.themeName -Palette $theme.themepalette -IsInverted $theme.isInverted
      LogSuccess "done"
    }
    else {
      LogInfo("Skipped")
    }
  }
  LogDuration $startDate
}

Function Apply-Theme ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnPPowerShell $global:tenantAdminUrl
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($siteInfo.Theme -and $siteInfo.Theme.FilePath) {
      $theme = Import-PowerShellDataFile $siteInfo.Theme.FilePath
      LogWaiting "Applying $($theme.themeName) theme to $($siteInfo.SiteUrl)"
      Set-PnPWebTheme -Theme $theme.themeName -WebUrl $siteInfo.SiteUrl
      LogSuccess "done"
    }
    else {
      LogInfo("Theme was not declared")
    }
  }
  LogDuration $startDate
}

Function Remove-Theme ($parameters) {
  $startDate = (Get-Date)
  Authenticate-PnPPowerShell $global:tenantAdminUrl
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($siteInfo.Theme -and $siteInfo.Theme.FilePath) {
      $theme = Import-PowerShellDataFile $siteInfo.Theme.FilePath
      if (Get-PnPTenantTheme | Where-Object { $_.Name -like $theme.themeName }) {
        LogWaiting "Removing $($theme.themeName) theme in $($global:tenantAdminUrl)"
        Remove-PnPTenantTheme -Identity $theme.themeName
        LogSuccess "done"
      }
      else {
        LogInfo("Theme was not found")
      }
    }
    else {
      LogInfo("Theme was not declared")
    }
  }
  LogDuration $startDate
}

Function Remove-Lists ($parameters) {
  LogInfo("Waiting 90 seconds to next step")
  Start-Sleep -s 90
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($siteInfo.ListsToRemove) {
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      $siteInfo.ListsToRemove | ForEach-Object {
        LogWaiting "Removing $_"
        Remove-PnPList -Identity $_ -Force 
        LogSuccess "done"
      }
    }
    else {
      LogInfo("No lists declared")
    }
  }
}

Function Add-CustomActions ($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($siteInfo.CustomActions) {
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      $siteInfo.CustomActions | ForEach-Object {
        LogWaiting "Adding $($_.Title) action to $($siteInfo.SiteUrl)"
        Add-PnPCustomAction -Name $_.Title -Title $_.Title -Location $_.Location -ClientSideComponentId $_.ClientSideComponentId -ClientSideComponentProperties $_.ComponentProperties 
        LogSuccess "done"
      }
    }
    else {
      LogInfo("No custom actions declared")
    }
  }
  LogDuration $startDate
}

# Launch a browser window at the new site collection URL to init config
Function Launch-Browser ($parameters) {
  $parameters.SiteCollectionInfos | ForEach-Object {
    if ($_.SiteUrl) {
      Start-Process $_.SiteUrl
    }
  }
}

# Configure CDN
Function Configure-Cdn ($parameters) { 
  $startDate = (Get-Date)
  LogWaiting "Configuring"
  $parameters.SiteCollectionInfos | ForEach-Object {
    Authenticate-PnPPowerShell $global:tenantAdminUrl
    $relativeUrl = $_.SiteUrl.Replace($global:tenantUrl, '')
    Set-CdnConfiguration $relativeUrl
  }
  LogSuccess "done"
  LogDuration $startDate
}

Function Upload-Resources($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($siteInfo.Resources) {
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      $siteInfo.Resources | ForEach-Object {
        $uploadInfo = $_
        LogWaiting "Adding files from $($uploadInfo.OriginFolder) to  $($uploadInfo.TargetLibrary) in $($siteInfo.SiteUrl)"
        Get-ChildItem $uploadInfo.OriginFolder | ForEach-Object {
          $out = Add-PnPFile -Path $_.FullName -Folder $uploadInfo.TargetLibrary
        }
        LogSuccess "done"
      }
    }
  }
  LogDuration $startDate
}

Function Add-SiteLogo($parameters) {
  $startDate = (Get-Date)
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($siteInfo.SiteLogo) {
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      $siteRelativeUrl = $siteInfo.SiteUrl -replace $global:tenantUrl, ""
      $fileRelativeUrl = "$siteRelativeUrl/$($siteInfo.SiteLogo.TargetLibrayName)/$($siteInfo.SiteLogo.FileName)"
      if (Get-PnPFile -Url $fileRelativeUrl -ErrorAction SilentlyContinue) {
        Remove-PnPFile -ServerRelativeUrl $fileRelativeUrl -Force
      }
      $out = Add-PnPFile -Path "$($siteInfo.SiteLogo.SourceFolderPath)\$($siteInfo.SiteLogo.FileName)" -Folder $siteInfo.SiteLogo.TargetLibrayName
      Set-PnPWeb -SiteLogoUrl $fileRelativeUrl
    }
    else {
      LogInfo("Logo was not declared")
    }
  }
  LogDuration $startDate
}


Function Update-TermCustomProperty($parameters) {
  if ($null -ne $parameters.TermCustomProperties) {
    $startDate = (Get-Date)
    Authenticate-PnPPowerShell $global:tenantAdminUrl
    $parameters.TermCustomProperties | ForEach-Object {
      $t = $_
      $term = Get-PnPTerm -TermGroup $t.TermGroupName -TermSet $t.TermSetName -Identity $t.TermName
      $ctx = Get-PnPContext
      $ctx.Load($term)
      $ctx.ExecuteQuery()
      #$term.LocalCustomProperties
      if ($t.CustomProperties) {
        $t.CustomProperties | ForEach-Object {
          $term.SetLocalCustomProperty($_.Name, $_.Value)
          LogInfo "Updated $($t.TermName): $($_.Name) = $($_.Value)"
        }
      }
      if ($t.DynamicCustomProperties) {
        $t.DynamicCustomProperties | ForEach-Object {
          $value = & $_.Function
          $term.SetLocalCustomProperty($_.Name, $value)
          LogInfo "Updated $($t.TermName): $($_.Name) = $($value)"
        }
      }
      $ctx.ExecuteQuery()
    }
    LogDuration $startDate
  }
  else {
    LogInfo("Skipped")
  }
}

Function Add-OrgAssetsLibrary($parameters) {
  if ($null -ne $parameters.SiteCollectionInfos -and $null -ne $parameters.SiteCollectionInfos[0].OrgAssetsLibraries) {
    $siteInfo = $parameters.SiteCollectionInfos[0]
    Authenticate-PnpPowerShell $siteInfo.SiteUrl
    #Create libraries
    LogWaiting "Creating assets library in $($siteInfo.SiteUrl)"
    $ct = Get-PnPContentType -Identity "Fresh document" -ErrorAction SilentlyContinue
    $siteInfo.OrgAssetsLibraries  | ForEach-Object {
      if (-not (Get-PnPList $_.LibraryUrl)) {
        New-PnPList -Template DocumentLibrary -Title $_.LibraryTitle -Url $_.LibraryUrl
      }
      #Add Fresh document content type, if it exsits in the site
      if ($ct) {
        Add-PnPContentTypeToList -List $_.LibraryUrl -ContentType $ct
      }
    }
    LogSuccess "done"
    Authenticate-PnPPowerShell $global:tenantAdminUrl
    #Enable CDN
    if (-not (Get-PnPTenantCdnEnabled -CdnType private).Value) {
      LogWaiting "Enabling CDN"
      Set-PnPTenantCdnEnabled -CdnType private -Enable $true
      Start-Sleep -s 90
      LogSuccess "done"
      Disconnect-PnPOnline
      Authenticate-PnPPowerShell $global:tenantAdminUrl
    }
    #Set libraries as global assets
    LogWaiting "Setting the library as Organizational assets library"
    $siteInfo.OrgAssetsLibraries  | ForEach-Object {
      Add-PnPOrgAssetsLibrary -LibraryUrl "$($siteInfo.SiteUrl)/$($_.LibraryUrl)"
    }

    LogSuccess "done"
  }
}

Function Add-OrganizationNews($parameters) {
  if ($null -ne $parameters.SiteCollectionInfos) {
    Authenticate-PnpPowerShell $global:tenantAdminUrl
    $parameters.SiteCollectionInfos | ForEach-Object {
      $siteInfo = $_
      LogWaiting "Setting the site $($siteInfo.SiteUrl) as a source of organization news"
      Add-PnPOrgNewsSite -OrgNewsSiteUrl $siteInfo.SiteUrl
      LogSuccess "done"
    }
  }
}

Function Set-SiteAsHomeSite($parameters) {
  if ($null -ne $parameters.SiteCollectionInfos -and $parameters.SiteCollectionInfos[0].IsHomeSite) {
    Authenticate-PnpPowerShell $global:tenantAdminUrl
    $siteInfo = $parameters.SiteCollectionInfos[0]
    LogWaiting "Setting the site $($siteInfo.SiteUrl) as home site"
    Set-PnPHomeSite -Url $siteInfo.SiteUrl
    LogSuccess "done"
  }
}

Function Set-SearchResultsPageUrl($parameters) {
  $count = 0
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($null -ne $siteInfo.SearchResultPageUrl) {
      LogWaiting "Setting the custom search results page of the site $($siteInfo.SiteUrl)"
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      Set-PnPSearchSettings -SearchPageUrl $siteInfo.SearchResultPageUrl -Scope Web
      $count++
      LogSuccess "done"
    }
  }
  if ($count -eq 0) {
    LogInfo("Skipped")
  }
}

Function Execute-PostProvisioningFunction($parameters) {
  $count = 0
  $parameters.SiteCollectionInfos | ForEach-Object {
    $siteInfo = $_
    if ($null -ne $siteInfo.PostProvisioningFunction) {
      LogWaiting $siteInfo.PostProvisioningFunction.Message
      Authenticate-PnpPowerShell $siteInfo.SiteUrl
      & $siteInfo.PostProvisioningFunction.Function -parameters $Parameters
      $count++
      LogSuccess "done"

    }
  }
  if ($count -eq 0) {
    LogInfo("Skipped")
  }
}

Function Deploy-ChildEntities($parameters) {
  if ($null -ne $parameters.ChildEntities) {
    $paramsFile = "$PSScriptRoot\..\Deploy-Entities\Parameters"
    Import-Module $paramsFile -Force
    $moduleParameters = $parameters.ChildEntities
    $params = Get-Parameters @moduleParameters
    $deployFile = "$PSScriptRoot\..\Deploy-Entities\Steps"
    Import-Module $deployFile -Force
    $steps = Get-Steps
    Deploy-Steps -Steps $steps -Parameters $params
  }
  else {
    LogInfo("Skipped")
  }
}


Function Deploy-InitialTenantModules($parameters) {
  $parameters.Modules.InitialTenantModules | Where-Object { $_.Enabled } | ForEach-Object {
    $paramsFile = Join-Path -Path $_.Module.Path -ChildPath "Parameters"
    Import-Module $paramsFile -Force
    $moduleParameters = $_.ModuleParameters
    $params = Get-Parameters @moduleParameters
    $deployFile = Join-Path -Path $_.Module.Path -ChildPath "Steps"
    Import-Module $deployFile -Force
    $steps = Get-Steps
    Deploy-Steps -Steps $steps -Parameters $params
  }
}

Function Deploy-FinalTenantModules($parameters) {
  $parameters.Modules.FinalTenantModules | Where-Object { $_.Enabled } | ForEach-Object {
    $paramsFile = Join-Path -Path $_.Module.Path -ChildPath "Parameters"
    Import-Module $paramsFile -Force
    $moduleParameters = $_.ModuleParameters
    $params = Get-Parameters @moduleParameters
    $deployFile = Join-Path -Path $_.Module.Path -ChildPath "Steps"
    Import-Module $deployFile -Force
    $steps = Get-Steps
    Deploy-Steps -Steps $steps -Parameters $params
  }
}

Function Deploy-InstanceModules($parameters) {
  $parameters.Modules.InstanceModules | ForEach-Object {
    $instance = $_ 
    $instance.Modules | Where-Object { $_.Enabled } | ForEach-Object {
      $paramsFile = Join-Path -Path $_.Module.Path -ChildPath "Parameters"
      Import-Module $paramsFile -Force
      $moduleParameters = $_.ModuleParameters
      $moduleParameters.Instance = $instance.Instance
      $params = Get-Parameters @moduleParameters
      $deployFile = Join-Path -Path $_.Module.Path -ChildPath "Steps"
      Import-Module $deployFile -Force
      $steps = Get-Steps
      if ($instance.SkipTenantSteps) {
        Deploy-Steps -Steps $steps -Parameters $params -IncludeOnly @("InstanceSteps", "SiteSteps")
      }
      else {
        Deploy-Steps -Steps $steps -Parameters $params
      }
    }
  }
}


# STEP DEFINITIONS
$deploySteps = @{
  PublishAppPackages                  = @{
    Name     = "Publish app packages in the app catalog" # For log purposes only.
    Function = Get-Item function:Publish-AppPackages
  }
  DeleteSiteCollections               = @{
    Name     = "Delete site collections" # For log purposes only.
    Function = Get-Item function:Delete-SiteCollections
  }
  RemoveSiteCollectionsFromRecycleBin = @{
    Name     = "Empty site collections from recycle bin" # For log purposes only.
    Function = Get-Item function:Remove-SiteCollectionsFromRecycleBin
  }
  CreateSiteCollections               = @{
    Name     = "Create site collections" # For log purposes only.
    Function = Get-Item function:Create-SiteCollections
  }
  RegisterHubSites                    = @{
    Name     = "Register hub sites" # For log purposes only.
    Function = Get-Item function:Register-HubSites
  }
  JoinHubSites                        = @{
    Name     = "Associate site collections to hub sites" # For log purposes only.
    Function = Get-Item function:Join-HubSites
  }
  ApplyProvisioningTemplate           = @{
    Name     = "Apply provisioning template" # For log purposes only.
    Function = Get-Item function:Apply-ProvisioningTemplate
  }
  ApplyProvisioningTemplateArray      = @{
    Name     = "Apply array of provisioning templates" # For log purposes only.
    Function = Get-Item function:Apply-ProvisioningTemplateArray
  }
  ApplySiteScript                     = @{
    Name     = "Apply site scripts" # For log purposes only.
    Function = Get-Item function:Apply-SiteScript
  }
  ApplySiteDesign                     = @{
    Name     = "Apply site scripts" # For log purposes only.
    Function = Get-Item function:Apply-SiteDesign
  }
  InstallAppPackages                  = @{
    Name     = "Install apps in site collections" # For log purposes only.
    Function = Get-Item function:Install-AppPackages
  }
  ImportSearchSchema                  = @{
    Name     = "Import search schema" # For log purposes only.
    Function = Get-Item function:Import-SearchSchema
  }
  ImportTaxonomies                    = @{
    Name     = "Import taxonomy" # For log purposes only.
    Function = Get-Item function:Import-TaxonomyFiles
  }
  ImportInstanceTaxonomies            = @{
    Name     = "Import the taxonomy for current instance" # For log purposes only.
    Function = Get-Item function:Import-InstanceTaxonomyFiles
  }
  CreateTerms                         = @{
    Name     = "Create terms" # For log purposes only.
    Function = Get-Item function:Create-TaxonomyTerms
  }
  LaunchBrowser                       = @{
    Name     = "Launch browser" # For log purposes only.
    Function = Get-Item function:Launch-Browser
  }
  ConfigureCdn                        = @{
    Name     = "Configure CDN" # For log purposes only.
    Function = Get-Item function:Configure-Cdn
  }
  AddCustomActions                    = @{
    Name     = "Add custom actions" # For log purposes only.
    Function = Get-Item function:Add-CustomActions
  }
  AddTheme                            = @{
    Name     = "Add theme in the tenant" # For log purposes only.
    Function = Get-Item function:Add-Theme
  }
  ApplyTheme                          = @{
    Name     = "Appy theme to the site" # For log purposes only.
    Function = Get-Item function:Apply-Theme
  }
  RemoveTheme                         = @{
    Name     = "Remove theme in the tenant" # For log purposes only.
    Function = Get-Item function:Remove-Theme
  }
  UploadResources                     = @{
    Name     = "Upload files" # For log purposes only.
    Function = Get-Item function:Upload-Resources
  }
  AddSiteLogo                         = @{
    Name     = "Add site logo" # For log purposes only.
    Function = Get-Item function:Add-SiteLogo
  }
  UpdateTermCustomProperty            = @{
    Name     = "Update term" # For log purposes only.
    Function = Get-Item function:Update-TermCustomProperty
  }
  AddSampleContent                    = @{
    Name     = "Add sample content" # For log purposes only.
    Function = Get-Item function:Add-SampleContent
  }  
  CreateOrgAssetsLibrary              = @{
    Name     = "Create Org assets libraries" # For log purposes only.
    Function = Get-Item function:Add-OrgAssetsLibrary
  }  
  SetSitesAsOrganizationNews          = @{
    Name     = "Set the sites as an organization news source" # For log purposes only.
    Function = Get-Item function:Add-OrganizationNews
  }  
  SetSearchResultsPage                = @{
    Name     = "Set the custom results page URL in the search settings" # For log purposes only.
    Function = Get-Item function:Set-SearchResultsPageUrl
  } 
  SetSiteAsHomeSite                   = @{
    Name     = "Set site as Home site" # For log purposes only.
    Function = Get-Item function:Set-SiteAsHomeSite
  }  
  RemoveLists                         = @{
    Name     = "Remove lists" # For log purposes only.
    Function = Get-Item function:Remove-Lists
  }  
  ExecutePostProvisioningFunction     = @{
    Name     = "Execute function after applying provisioning" # For log purposes only.
    Function = Get-Item function:Execute-PostProvisioningFunction
  }
  DeployChildEntities                 = @{
    Name     = "Deploy a set of entites" # For log purposes only.
    Function = Get-Item function:Deploy-ChildEntities
  } 
  DeployInitialTenantModules          = @{
    Name     = "Deploy initial tenant modules" # For log purposes only.
    Function = Get-Item function:Deploy-InitialTenantModules
  }
  DeployFinalTenantModules            = @{
    Name     = "Deploy final tenant modules" # For log purposes only.
    Function = Get-Item function:Deploy-FinalTenantModules
  }
  DeployInstanceModules               = @{
    Name     = "Deploy instance module" # For log purposes only.
    Function = Get-Item function:Deploy-InstanceModules
  }

}