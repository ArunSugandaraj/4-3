﻿#Import-Module AzureRM.Resources

$selfSignedCertCERPath

$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
$cert.Import($selfSignedCertCERPath)
$rawCert = $cert.GetRawCertData()
$base64Cert = [System.Convert]::ToBase64String($rawCert)
$rawCertHash = $cert.GetCertHash()
$base64CertHash = [System.Convert]::ToBase64String($rawCertHash)
$KeyId = [System.Guid]::NewGuid().ToString()


$pfxFileBytes = get-content $selfSignedCertPFXPath -Encoding Byte
$pfxBase64 = [System.Convert]::ToBase64String($pfxFileBytes)

$keyCredentials = 
'"keyCredentials": [
    {
      "customKeyIdentifier": "'+ $base64CertHash + '",
      "keyId": "' + $KeyId + '",
      "type": "AsymmetricX509Cert",
      "usage": "Verify",
      "value":  "' + $base64Cert + '"
     }
  ],'

$CertificateThumbprint = $cert.Thumbprint

#$keyCredentials = New-Object  Microsoft.Azure.Commands.Resources.Models.ActiveDirectory.PSADKeyCredential
#$keyCredentials.KeyId = $KeyId 
#$keyCredentials.StartDate = $selfSignedCertStartDate
#$keyCredentials.EndDate = $selfSignedCertEndDate
#$keyCredentials.CertValue = $base64Cert

#$keyCredentials

#Write-Host "Thumbprint: $CertificateThumbprint"