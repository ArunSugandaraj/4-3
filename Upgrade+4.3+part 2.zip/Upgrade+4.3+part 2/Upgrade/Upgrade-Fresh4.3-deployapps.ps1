# Files may be blocked if sent via the internet, this ensures that we unblock them
# Will fail if PowerShell was not opened as Administrator
Get-ChildItem '..' -Recurse | Unblock-File

# Add variables and functions
. ..\Environment.ps1
. ..\Utilities\UpgradeUtilities.ps1

try {
  Start-Transcript -path $CONSTANTS.PathToLogFile -ErrorAction SilentlyContinue
}
catch [System.Exception] {
  LogWarning "Unable to start transcription of this session" -f Red
}

$startDate = (Get-Date)
LogInfo ("Script started: " + $startDate.ToString())

try {
  
  # 1. Update solutions
  #######################
  Write-Host "Update solutions" -ForegroundColor "yellow"
  Authenticate-PnpPowerShell $global:tenantUrl
  Update-Solutions -Provisioning -WebAnalytics -CheckList #-Search
  
  Write-Host "All solutions have been uploaded in the app catalog" -ForegroundColor "green"


  # 2. Create managed properties for tools
  #######################
  Write-Host "Create managed properties for tools" -ForegroundColor "yellow"
  $filePath = "$PSScriptRoot\4.3\tools-search.xml"
  Authenticate-PnPPowerShell $global:tenantAdminUrl
  LogWaiting "Importing $filePath"
  Set-PnPSearchConfiguration -Path $filePath -Scope "Subscription"
  LogSuccess "done"

}
catch [System.Exception] {
  LogError $_ -f Red
  LogError
  LogError $_.ScriptStackTrace
  LogError
  LogError $_.Exception
  LogError
  LogError $_.ErrorDetails
}
finally {
  LogSection "Script end"
  $endDate = (Get-Date)
  LogInfo ("Script started: " + $startDate.ToString())
  LogInfo ("Script ended: " + $endDate.ToString())

  Stop-Transcript -ErrorAction SilentlyContinue
}
