# Files may be blocked if sent via the internet, this ensures that we unblock them
# Will fail if PowerShell was not opened as Administrator
Get-ChildItem '..' -Recurse | Unblock-File

# Add variables and functions
. ..\Environment.ps1
. ..\Utilities\UpgradeUtilitiesAzure.ps1

# ONLY IF PROVISIONING MODULE IS DEPLOYED

#-------------------------------------------
# 1. Deploy changes in provisioning engine
############################################
Write-Host "Upgrading Provisioning Function App" -ForegroundColor "yellow"

$zipPackagePath = "$PSScriptRoot\4.3\CandC.ProvisioningFunctions.zip"

Upgrade-ProvisioningAzureFunctionApp -zipPackagePath $zipPackagePath


#-------------------------------------------
# 2. Upload community site template to fix bug
############################################
Write-Host "Replace community site template" -ForegroundColor "yellow"
$source = "$PSScriptRoot\4.3\CC.Community.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Community.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder


