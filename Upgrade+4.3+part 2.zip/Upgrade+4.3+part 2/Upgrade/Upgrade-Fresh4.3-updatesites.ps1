# Files may be blocked if sent via the internet, this ensures that we unblock them
# Will fail if PowerShell was not opened as Administrator
Get-ChildItem '..' -Recurse | Unblock-File

# Add variables and functions
. ..\Environment.ps1
. ..\Utilities\DeployUtilities.ps1
Import-Module ..\Utilities\DeployConstants -Force
Import-Module ..\Files\Instances -Force
$instances = Get-Instances

try {
  Start-Transcript -path $CONSTANTS.PathToLogFile -ErrorAction SilentlyContinue
}
catch [System.Exception] {
  LogWarning "Unable to start transcription of this session" -f Red
}


$instancesToUpgrade = $instances.Values #all the instances
$sites = @()

Authenticate-PnpPowerShell $global:tenantAdminUrl
$instancesToUpgrade | Foreach-Object {
  if ($null -ne $_.InstancePrefix -and "" -ne $_.InstancePrefix) {
    Get-PnPTenantSite -Filter "Url -like '/sites/$($_.InstancePrefix)'" | ForEach-Object { $sites += $_.Url }
  }
  else {
    $results = Submit-PnPSearchQuery -Query "FreshInstance=$($_.InstanceStamp)" -SelectProperties "Path"
    $results.ResultRows | ForEach-Object { $sites += $_.Path }
  }
}


Write-Host "The apps will be updated in the following Fresh sites ($($sites.Length)):" -ForegroundColor Yellow
$sites | Foreach-Object { Write-Host "   $_" }
$left = New-TimeSpan -Seconds ($sites.Length * 3)
LogWarning "The process will take around$(if($left.Hours -gt 0) {" $($left.Hours) hours"}) $($left.Minutes) minutes$(if($left.Seconds -gt 0) {" and $($left.Seconds) seconds"})."
Read-Host "Press Enter to continue"


function UpdateSite($SiteUrl) {
  try {
    Set-Location $PSScriptRoot
    Import-Module ..\Utilities\DeployConstants -Force
    . ..\Environment.ps1
    . ..\Utilities\DeploySteps

    Authenticate-PnpPowerShell $SiteUrl

    $appPackages = @(
      @{ app = $CONSTANTS.AppPackages.MediaWebparts; action = "UPDATE_OR_INSTALL"; check = $true }
    )

    ##
    # 1. Install the app in the site
    #######################
    $apps = Get-PnPApp
    $appPackages | ForEach-Object {
      $appDefinition = $_
      $appInfo = Get-PnPAppInfo -ProductId $appDefinition.app.ProductId
      $app = $apps | Where-Object { $_.Title -eq $appInfo.Name }
      if ($app -and $app.Id) {
        if ($app.InstalledVersion) {
          if ($app.InstalledVersion.Major -ne 4 -or $app.InstalledVersion.Minor -ne 3) {
            LogWaiting "Updating $($app.Title) app" -ForegroundColor "yellow"
            Update-PnPApp -Identity $app.Id
            LogSuccess "done"
          }
          else {
            LogWarning "The $($app.Title) app is already upgraded"
          }
        }
        else {
          if ($appDefinition.action -eq "UPDATE_OR_INSTALL") {
            LogWaiting "Installing $($app.Title) app" -ForegroundColor "yellow"
            Install-PnPApp -Identity $app.Id
            LogSuccess "done"
          }
          else {
            LogInfo "Skip $($app.Title) app installation"
          }
        }
      }
      else {
        LogError "$($appDefinition.app.FilePath) app not found in the app catalog"      
      }
    }

    ##
    # 1. Update tools list
    #######################
    if (Get-PnPContentType -Identity "Tool" -ErrorAction SilentlyContinue) {
      Write-Host "Update tools list" -ForegroundColor "yellow"
      if ( -not (Get-PnPField -Identity "CandC_MobileOnly" -ErrorAction SilentlyContinue )) {
        Write-Host "Adding column to " $_
        Add-PnPField -InternalName "CandC_WhiteText" -DisplayName "Use white text" -Type Boolean -Group "Fresh Columns" -Id "a3deead5-c4c3-4228-8a51-da44b85c325e"
        Add-PnPField -InternalName "CandC_MobileOnly" -DisplayName "Mobile only" -Type Boolean -Group "Fresh Columns" -Id "4702a98f-dde5-4326-acc2-86ebc65834ff"
        Add-PnPField -InternalName "CandC_DesktopOnly" -DisplayName "Desktop only" -Type Boolean -Group "Fresh Columns" -Id "f7e88af3-9cc0-463a-a37f-f369a8f05edc"
        Add-PnPFieldToContentType -Field "CandC_WhiteText" -ContentType "Tool"
        Add-PnPFieldToContentType -Field "CandC_MobileOnly" -ContentType "Tool"
        Add-PnPFieldToContentType -Field "CandC_DesktopOnly" -ContentType "Tool"      
      }
      else {
        Write-Host $_ "The tools list already has the new columns"
      }
    }
    #else {
    #  Write-Host $_ "doesn't have a Tool content type" 
    #}

  }
  catch {
    Write-Host $_.Exception
  }
}


$i = 0
$startDate = (Get-Date)
$sites | Foreach-Object {
  $i++
  $tempDate = (Get-Date)
  #Start-Job -ScriptBlock ${Function:UpdateSite} -ArgumentList @($_, $PSScriptRoot) | Wait-Job | Receive-Job
  UpdateSite $_
  LogDuration $tempDate
  $left = New-TimeSpan -Seconds (($sites.Length - $i) * 3)
  LogSuccess "$i sites of $($sites.Length) processed. The process will be finish in about$(if($left.Hours -gt 0) {" $($left.Hours) hours"}) $($left.Minutes) minutes$(if($left.Seconds -gt 0) {" and $($left.Seconds) seconds"})."
}
LogDuration $startDate

Stop-Transcript -ErrorAction SilentlyContinue

