. ..\Environment.ps1

$credentials = Get-Credential -Credential $global:defaultSiteOwner
$credentials | Export-CliXml -Path $global:storedCredentialsPath